#define LOAD_ASSETS()  GD.safeload("tiled.gd2");
#define METAL_HANDLE 0
#define METAL_WIDTH 256
#define METAL_HEIGHT 256
#define METAL_CELLS 1
#define ASSETS_END 65536UL
static const shape_t METAL_SHAPE = {0, 256, 256, 0};
